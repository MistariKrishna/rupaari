import type { CSSProperties } from "react";
import type { Tone } from "@/lib/content";
import Media from "./Media";

/** Dark intro band used at the top of every inner page (works under the transparent header). */
export default function PageHero({ eyebrow, title, intro, tone = "wine" }: { eyebrow: string; title: string; intro?: string; tone?: Tone }) {
  return (
    <section className="on-dark relative flex min-h-[62svh] items-end overflow-hidden bg-wine text-ivory">
      <Media tone={tone} className="absolute inset-0 h-full w-full" />
      <div className="absolute inset-0 bg-gradient-to-t from-wine/85 via-wine/20 to-wine/40" aria-hidden="true" />
      <div className="container-x relative z-10 pb-[clamp(3rem,8vh,6rem)] pt-40">
        <p className="t-eyebrow eyebrow-rule hero-in mb-5" style={{ "--d": "150ms" } as CSSProperties}>{eyebrow}</p>
        <h1 className="t-hero max-w-[18ch]">
          <span className="line-mask"><span style={{ "--d": "300ms" } as CSSProperties}>{title}</span></span>
        </h1>
        {intro && (
          <p className="t-lead hero-in mt-6 max-w-[40rem] text-ivory/90" style={{ "--d": "650ms" } as CSSProperties}>
            {intro}
          </p>
        )}
      </div>
    </section>
  );
}
