"use client";

import Link from "next/link";
import { useEffect, useRef, type CSSProperties } from "react";
import { Icon } from "./Icon";
import Media from "./Media";

export default function Hero() {
  const bg = useRef<HTMLDivElement>(null);
  const fg = useRef<HTMLDivElement>(null);

  // Gentle parallax: background drifts slower than the page, content fades as you leave.
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const update = () => {
      const y = window.scrollY;
      const h = window.innerHeight;
      if (y > h * 1.3) return;
      if (bg.current) bg.current.style.transform = `translate3d(0, ${y * 0.28}px, 0) scale(1.08)`;
      if (fg.current) {
        fg.current.style.transform = `translate3d(0, ${y * -0.08}px, 0)`;
        fg.current.style.opacity = String(Math.max(0, 1 - y / (h * 0.75)));
      }
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <section className="on-dark relative flex min-h-[100svh] items-end overflow-hidden bg-wine text-ivory" aria-label="Introduction">
      <div ref={bg} className="absolute inset-0 will-change-transform">
        {/* Replace with a looping video: <Media video="/videos/hero.mp4" poster="/images/hero.jpg" /> */}
        <Media tone="wine" className="h-full w-full" priority />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-wine/85 via-wine/25 to-wine/40" aria-hidden="true" />

      <div ref={fg} className="container-x relative z-10 pb-[clamp(5rem,12vh,9rem)] pt-40 will-change-transform">
        <p className="t-eyebrow eyebrow-rule hero-in mb-6" style={{ "--d": "200ms" } as CSSProperties}>
          Tradition in every thread
        </p>
        <h1 className="t-hero max-w-[16ch]">
          <span className="line-mask"><span style={{ "--d": "350ms" } as CSSProperties}>Pure silk.</span></span>
          <span className="line-mask"><span style={{ "--d": "480ms" } as CSSProperties}>Honest zari.</span></span>
        </h1>
        <p className="t-lead hero-in mt-7 max-w-[34rem] text-ivory/90" style={{ "--d": "800ms" } as CSSProperties}>
          Heirloom spirit. Contemporary ease. South Indian silk sarees, woven by hand and made to be lived in.
        </p>
        <div className="hero-in mt-9 flex flex-wrap gap-4" style={{ "--d": "950ms" } as CSSProperties}>
          <Link href="/collections/sarees" className="btn btn-light">
            Explore sarees <Icon name="arrow-right" />
          </Link>
          <Link href="/about" className="btn btn-ghost">
            Our story
          </Link>
        </div>
      </div>

      <div className="hero-in absolute bottom-8 right-[var(--gutter)] z-10 hidden flex-col items-center gap-3 text-[10px] uppercase tracking-[.3em] text-ivory/80 md:flex" style={{ "--d": "1300ms" } as CSSProperties} aria-hidden="true">
        Scroll
        <span className="scroll-cue" />
      </div>
    </section>
  );
}
