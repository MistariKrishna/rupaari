import Image from "next/image";
import type { Tone } from "@/lib/content";

interface Props {
  /** woven-art colour tone, used when no image/video is supplied */
  tone?: Tone;
  /** path in /public, e.g. "/images/hero.jpg" (gets a slow Ken Burns zoom) */
  image?: string;
  /** path in /public, e.g. "/videos/hero.mp4": muted, looping, autoplay */
  video?: string;
  poster?: string;
  alt?: string;
  sizes?: string;
  priority?: boolean;
  className?: string;
}

/**
 * Media slot used everywhere a davaris-style looping video/photo would sit.
 * Drop a file in /public and pass `video` or `image` to replace the woven art.
 */
export default function Media({ tone = "wine", image, video, poster, alt = "", sizes = "100vw", priority = false, className = "" }: Props) {
  if (video) {
    return (
      <div className={`relative overflow-hidden ${className}`.trim()}>
        <video className="absolute inset-0 h-full w-full object-cover" src={video} poster={poster} autoPlay muted loop playsInline preload="metadata" aria-hidden="true" />
      </div>
    );
  }
  if (image) {
    return (
      <div className={`relative overflow-hidden ${className}`.trim()}>
        <Image src={image} alt={alt} fill sizes={sizes} priority={priority} className="kb object-cover" />
      </div>
    );
  }
  return <div className={`weave tone-${tone} ${className}`.trim()} aria-hidden="true" />;
}
