import type { ReactNode } from "react";

// Outline icon library (design system 04): 24x24 grid, 1.5px stroke, round ends.
const paths = {
  "arrow-right": <path d="M5 12h14M13 6l6 6-6 6" />,
  check: <path d="M5 12l5 5 9-10" />,
  warning: (<><path d="M12 4l9 16H3z" /><path d="M12 10v4.5M12 17h.01" /></>),
  instagram: (<><rect x="4" y="4" width="16" height="16" rx="4.5" /><circle cx="12" cy="12" r="3.6" /><path d="M16.8 7.2h.01" /></>),
  facebook: <path d="M14 8h2V4.5h-2.4C11.2 4.5 10 6 10 8.2V10H8v3.4h2V20h3.4v-6.6h2.3L16 10h-2.6V8.4c0-.3.2-.4.6-.4z" />,
  pinterest: (<><circle cx="12" cy="12" r="8.5" /><path d="M11 16.5l1.8-7.2M10.2 13.2c-.8-2.2.6-4.2 2.6-4.2 1.7 0 2.6 1.2 2.4 2.7-.2 1.6-1.2 2.7-2.3 2.7-.8 0-1.3-.6-1.1-1.4" /></>),
  linkedin: (<><rect x="4" y="4" width="16" height="16" rx="2.5" /><path d="M8.5 10.5V16M8.5 8h.01M11.5 16v-5.5M11.5 13c0-1.6 1-2.6 2.3-2.6 1.4 0 2.2.9 2.2 2.4V16" /></>),
} satisfies Record<string, ReactNode>;

export type IconName = keyof typeof paths;

export function Icon({ name, className = "" }: { name: IconName; className?: string }) {
  return (
    <svg className={`icon ${className}`.trim()} viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      {paths[name]}
    </svg>
  );
}
