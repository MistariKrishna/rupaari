import Link from "next/link";
import { site, menu } from "@/lib/site";
import { Icon } from "./Icon";
import Reveal from "./Reveal";

const link = "inline-flex min-h-9 items-center text-[14px] text-ivory/80 transition-colors hover:text-ivory";
const head = "mb-4 text-[12px] font-medium uppercase tracking-[.22em] text-ivory";

export default function Footer() {
  const { address, phone, email } = site.contact;
  const socials = site.social.filter((s) => s.href);

  return (
    <footer className="on-dark bg-wine pb-8 pt-20 text-ivory">
      <div className="container-x">
        <Reveal>
          <div className="grid gap-12 border-b border-gold/40 pb-14 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
            <div>
              <Link href="/" className="font-display text-[clamp(2rem,4vw,3rem)] uppercase leading-none tracking-[.03em]">
                Rupaari
              </Link>
              <p className="mt-4 max-w-[28ch] text-ivory/80">{site.tagline}. Heirloom spirit, contemporary ease.</p>
            </div>

            <div>
              <h2 className={head + " !font-sans"}>Sitemap</h2>
              <ul className="m-0 list-none p-0">
                {menu.map((m) => (
                  <li key={m.label}>
                    <Link href={m.href} className={link}>{m.label}</Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h2 className={head + " !font-sans"}>Collections</h2>
              <ul className="m-0 list-none p-0">
                {menu.find((m) => m.label === "Collections")?.children?.map((c) => (
                  <li key={c.label}>
                    <Link href={c.href} className={link}>{c.label}</Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h2 className={head + " !font-sans"}>Contact</h2>
              {address || phone || email ? (
                <address className="m-0 not-italic text-[14px] text-ivory/80">
                  {address && <p>{address}</p>}
                  {phone && <p>{phone}</p>}
                  {email && <p>{email}</p>}
                </address>
              ) : (
                <p className="text-[14px] text-ivory/80">Reach us through the contact page.</p>
              )}
              <Link href="/contact" className="link-arrow mt-3">
                Contact us <Icon name="arrow-right" />
              </Link>
              {socials.length > 0 && (
                <ul className="m-0 mt-5 flex list-none gap-2 p-0">
                  {socials.map((s) => (
                    <li key={s.name}>
                      <a href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.name} className="flex h-10 w-10 items-center justify-center rounded-full border border-ivory/50 transition-colors hover:bg-ivory hover:text-wine">
                        <Icon name={s.icon} className="!h-[18px] !w-[18px]" />
                      </a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </Reveal>

        <div className="flex flex-wrap justify-between gap-3 pt-6 text-[13px] text-ivory/70">
          <span>&copy; {new Date().getFullYear()} RUPAARI. All rights reserved.</span>
          <span>{site.tagline}</span>
        </div>
      </div>
    </footer>
  );
}
