"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { menu, site } from "@/lib/site";
import { Icon } from "./Icon";

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const closeBtn = useRef<HTMLButtonElement>(null);
  const toggleBtn = useRef<HTMLButtonElement>(null);
  const lastY = useRef(0);

  // Close the menu on navigation.
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  // Solid background after scrolling; hide when scrolling down, show when scrolling up.
  useEffect(() => {
    let raf = 0;
    const update = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      if (y > 320 && y > lastY.current + 4) setHidden(true);
      else if (y < lastY.current - 4 || y <= 320) setHidden(false);
      lastY.current = y;
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  // Lock page scroll while the menu is open; Escape closes it.
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleBtn.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    const t = setTimeout(() => closeBtn.current?.focus(), 500);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
      clearTimeout(t);
    };
  }, [open]);

  const solid = scrolled && !open;
  let i = 0;

  return (
    <>
      <header
        className={`on-dark fixed inset-x-0 top-0 z-50 text-ivory transition-all duration-500 ease-out ${
          hidden && !open ? "-translate-y-full" : "translate-y-0"
        } ${solid ? "bg-wine/90 shadow-[0_1px_0_rgba(201,162,77,.35)] backdrop-blur-md" : "bg-transparent"}`}
      >
        <div className={`container-x flex items-center justify-between transition-all duration-500 ${solid ? "min-h-[64px]" : "min-h-[84px]"}`}>
          <Link href="/" aria-label="RUPAARI home" className="relative z-[60] font-display text-[26px] uppercase leading-none tracking-[.03em] md:text-[30px]">
            Rupaari
          </Link>

          <div className="relative z-[60] flex items-center gap-4 md:gap-7">
            {site.social.some((s) => s.href) && (
              <ul className="m-0 hidden list-none gap-1 p-0 lg:flex">
                {site.social
                  .filter((s) => s.href)
                  .map((s) => (
                    <li key={s.name}>
                      <a href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.name} className="flex h-10 w-10 items-center justify-center transition-opacity hover:opacity-70">
                        <Icon name={s.icon} className="!h-5 !w-5" />
                      </a>
                    </li>
                  ))}
              </ul>
            )}
            <Link href={site.shopHref} className="link-arrow hidden sm:inline-flex">
              Shop <Icon name="arrow-right" />
            </Link>
            <button
              ref={toggleBtn}
              type="button"
              className="burger flex h-11 items-center gap-3 text-[12px] font-medium uppercase tracking-[.2em]"
              aria-expanded={open}
              aria-controls="site-menu"
              onClick={() => setOpen((v) => !v)}
            >
              <span className="hidden md:inline">{open ? "Close" : "Menu"}</span>
              <span className="bars relative flex h-[18px] w-7 flex-col justify-between py-[3px]" aria-hidden="true">
                <span />
                <span />
                <span />
              </span>
            </button>
          </div>
        </div>
      </header>

      <div
        id="site-menu"
        data-open={open}
        role="dialog"
        aria-modal="true"
        aria-label="Site menu"
        aria-hidden={!open}
        className="menu-overlay on-dark fixed inset-0 z-40 overflow-y-auto bg-wine text-ivory"
      >
        <div className="container-x grid min-h-full gap-12 pb-12 pt-28 md:grid-cols-[1.6fr_1fr] md:pt-36">
          <nav aria-label="Main">
            <ul className="m-0 list-none p-0">
              {menu.map((item) => {
                const idx = i++;
                return (
                  <li key={item.label} className="menu-item border-b border-ivory/15 py-3 md:py-4" style={{ "--i": idx } as CSSProperties}>
                    <Link
                      href={item.href}
                      tabIndex={open ? 0 : -1}
                      className="group inline-flex items-center gap-4 font-display text-[clamp(1.7rem,4.6vw,3.6rem)] uppercase leading-tight tracking-[.03em] transition-colors hover:text-gold"
                    >
                      {item.label}
                    </Link>
                    {item.children && (
                      <ul className="m-0 mt-2 flex list-none flex-wrap gap-x-6 gap-y-1 p-0">
                        {item.children.map((c) => (
                          <li key={c.label}>
                            <Link href={c.href} tabIndex={open ? 0 : -1} className="inline-flex min-h-9 items-center text-[13px] uppercase tracking-[.16em] text-ivory/80 transition-colors hover:text-ivory">
                              {c.label}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}
                  </li>
                );
              })}
            </ul>
          </nav>

          <div className="menu-item flex flex-col justify-end gap-8" style={{ "--i": menu.length + 1 } as CSSProperties}>
            <div>
              <p className="t-eyebrow mb-3 text-ivory/70">{site.tagline}</p>
              <p className="max-w-[26ch] text-ivory/85">Heirloom spirit. Contemporary ease.</p>
            </div>
            {(site.contact.address || site.contact.phone || site.contact.email) && (
              <address className="m-0 not-italic text-ivory/85">
                {site.contact.address && <p>{site.contact.address}</p>}
                {site.contact.phone && <p>{site.contact.phone}</p>}
                {site.contact.email && <p>{site.contact.email}</p>}
              </address>
            )}
            <Link href={site.shopHref} tabIndex={open ? 0 : -1} className="btn btn-light self-start">
              Shop <Icon name="arrow-right" />
            </Link>
            <button ref={closeBtn} type="button" tabIndex={open ? 0 : -1} className="self-start text-[12px] uppercase tracking-[.2em] text-ivory/80 underline underline-offset-8 hover:text-ivory" onClick={() => { setOpen(false); toggleBtn.current?.focus(); }}>
              Close menu
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
