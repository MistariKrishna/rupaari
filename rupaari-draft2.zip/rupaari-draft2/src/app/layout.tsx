import type { Metadata, Viewport } from "next";
import { Cinzel, Montserrat } from "next/font/google";
import "./globals.css";
import Footer from "@/components/Footer";
import Header from "@/components/Header";

// Cinzel is the design system's designated fallback for Trajan Pro (licensed).
const cinzel = Cinzel({ subsets: ["latin"], weight: "400", variable: "--font-cinzel", display: "swap" });
const montserrat = Montserrat({
  subsets: ["latin", "latin-ext"],
  weight: ["300", "400", "500"],
  variable: "--font-montserrat",
  display: "swap",
});

export const metadata: Metadata = {
  title: { default: "RUPAARI | Pure silk. Honest zari.", template: "%s | RUPAARI" },
  description: "RUPAARI: heirloom spirit, contemporary ease. South Indian silk sarees. Rediscover Yourself.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#4A0B13",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${cinzel.variable} ${montserrat.variable}`}>
      <body>
        {/* Without JS the scroll-reveal elements must still be visible. */}
        <noscript>
          <style>{`.rv,.hero-in,.line-mask>span,.menu-item{opacity:1!important;transform:none!important;clip-path:none!important;animation:none!important}`}</style>
        </noscript>
        <a href="#main" className="absolute left-[-999px] top-0 z-[100] bg-burgundy px-4 py-3 text-ivory focus:left-0">
          Skip to content
        </a>
        <Header />
        <main id="main">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
