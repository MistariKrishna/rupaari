import type { Metadata } from "next";
import ContactForm from "@/components/ContactForm";
import PageHero from "@/components/PageHero";
import Reveal from "@/components/Reveal";
import { site } from "@/lib/site";

export const metadata: Metadata = { title: "Contact", description: "Get in touch with RUPAARI." };

export default function ContactPage() {
  const { address, phone, email } = site.contact;
  return (
    <>
      <PageHero eyebrow="Contact" title="Let's talk" intro="Questions about a saree or an order? Write to us." tone="burgundy" />

      <section className="py-section">
        <div className="container-x grid gap-14 md:grid-cols-[1.4fr_1fr] md:gap-20">
          <Reveal>
            <ContactForm />
          </Reveal>
          <Reveal delay={140}>
            <h2 className="t-title mb-5 text-wine">Details</h2>
            {address || phone || email ? (
              <address className="m-0 not-italic text-ink/85">
                {address && <p className="mb-2">{address}</p>}
                {phone && <p className="mb-2">{phone}</p>}
                {email && <p>{email}</p>}
              </address>
            ) : (
              <p className="text-ink/70">Add your address, phone and email in <code>src/lib/site.ts</code>.</p>
            )}
          </Reveal>
        </div>
      </section>
    </>
  );
}
