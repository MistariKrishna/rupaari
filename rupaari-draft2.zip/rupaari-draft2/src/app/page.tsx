import Link from "next/link";
import Counter from "@/components/Counter";
import Hero from "@/components/Hero";
import { Icon } from "@/components/Icon";
import Media from "@/components/Media";
import Reveal from "@/components/Reveal";
import { collections, edits, stats } from "@/lib/content";

export default function HomePage() {
  return (
    <>
      <Hero />

      {/* Collections: three large cards, each a looping-video slot */}
      <section className="py-section" aria-labelledby="collections-title">
        <div className="container-x">
          <div className="mb-12 flex flex-wrap items-end justify-between gap-6 md:mb-16">
            <Reveal>
              <p className="t-eyebrow eyebrow-rule mb-5 text-burgundy">Collections</p>
              <h2 id="collections-title" className="t-section max-w-[16ch] text-wine">
                Woven for every moment
              </h2>
            </Reveal>
            <Reveal delay={120} variant="fade">
              <p className="max-w-[34ch] text-ink/80">Sarees, kurtis and gifts, each made to be worn, kept and passed on.</p>
            </Reveal>
          </div>

          <div className="grid gap-5 md:grid-cols-3 md:gap-6">
            {collections.map((c, i) => (
              <Reveal key={c.slug} delay={i * 130} variant="up">
                <Link href={`/collections/${c.slug}`} className="group on-dark relative block aspect-[4/5] overflow-hidden text-ivory md:aspect-[3/4]">
                  <div className="zoom absolute inset-0">
                    <Media tone={c.tone} className="h-full w-full" />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-wine/80 via-transparent to-transparent" aria-hidden="true" />
                  <div className="absolute inset-x-0 bottom-0 p-6 md:p-8">
                    <h3 className="t-title mb-3">{c.title}</h3>
                    <p className="mb-5 max-w-[30ch] text-[14px] text-ivory/85">{c.blurb}</p>
                    <span className="link-arrow">
                      View category <Icon name="arrow-right" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Who we are */}
      <section className="pb-section" aria-labelledby="who-title">
        <div className="container-x grid gap-10 md:grid-cols-[1fr_2.2fr] md:gap-16">
          <Reveal>
            <h2 id="who-title" className="t-eyebrow eyebrow-rule !font-sans text-burgundy">Who we are</h2>
          </Reveal>
          <div>
            <Reveal>
              <p className="t-statement text-wine">
                RUPAARI is a warm, considered language for South Indian silk sarees: heritage in character, clarity in every interaction.
              </p>
            </Reveal>
            <Reveal delay={150} variant="fade" className="mt-8">
              <Link href="/about" className="link-arrow text-burgundy">
                Read more <Icon name="arrow-right" />
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Key figures (SAMPLE numbers in src/lib/content.ts) */}
      <section className="on-dark bg-burgundy py-[clamp(4rem,8vw,7rem)] text-ivory" aria-label="Key figures">
        <div className="container-x">
          <dl className="m-0 grid grid-cols-2 gap-x-6 gap-y-12 md:grid-cols-5">
            {stats.map((s, i) => (
              <Reveal key={s.label} delay={i * 100} className={i === stats.length - 1 ? "col-span-2 md:col-span-1" : ""}>
                <div className="flex flex-col-reverse border-t border-gold pt-5">
                  <dt className="mt-3 text-[13px] uppercase tracking-[.14em] text-ivory/80">{s.label}</dt>
                  <dd className="m-0 font-display text-[clamp(2.4rem,4.6vw,4.2rem)] leading-none tracking-[.02em]">
                    <Counter value={s.value} suffix={s.suffix} />
                  </dd>
                </div>
              </Reveal>
            ))}
          </dl>
        </div>
      </section>

      {/* The loom: full-bleed media with text */}
      <section className="on-dark relative flex min-h-[80svh] items-end overflow-hidden bg-wine text-ivory" aria-labelledby="loom-title">
        <Media tone="burgundy" className="absolute inset-0 h-full w-full" />
        <div className="absolute inset-0 bg-gradient-to-t from-wine/90 via-wine/20 to-wine/30" aria-hidden="true" />
        <div className="container-x relative z-10 py-[clamp(3.5rem,9vw,7rem)]">
          <Reveal>
            <p className="t-eyebrow eyebrow-rule mb-5">The loom</p>
            <h2 id="loom-title" className="t-section mb-6 max-w-[14ch]">Made slowly, by hand</h2>
            <p className="t-lead mb-8 max-w-[34rem] text-ivory/90">From yarn to border to pallu, every piece is built on the loom, one pass of the shuttle at a time.</p>
            <Link href="/craft" className="btn btn-light">
              Discover the craft <Icon name="arrow-right" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Sustainability: two images + statement */}
      <section className="py-section" aria-labelledby="sustain-title">
        <div className="container-x grid items-center gap-12 md:grid-cols-12 md:gap-8">
          <div className="md:col-span-5">
            <Reveal>
              <p className="t-eyebrow eyebrow-rule mb-5 text-burgundy">Sustainability</p>
              <h2 id="sustain-title" className="t-section mb-6 text-wine">Slow by design</h2>
              <p className="t-lead mb-8 text-ink/85">
                Handloom is made by hand, in small batches, to last. Add your verified sustainability commitments here.
              </p>
              <Link href="/sustainability" className="link-arrow text-burgundy">
                Read more <Icon name="arrow-right" />
              </Link>
            </Reveal>
          </div>
          <div className="grid grid-cols-2 gap-4 md:col-span-7 md:gap-6">
            <Reveal variant="clip">
              <Media tone="taupe" className="aspect-[3/4] w-full" />
            </Reveal>
            <Reveal variant="clip" delay={180} className="mt-12 md:mt-24">
              <Media tone="gold" className="aspect-[3/4] w-full" />
            </Reveal>
          </div>
        </div>
      </section>

      {/* The edits (replaces davaris "upcoming events") */}
      <section className="bg-[#EFE5D4] py-section" aria-labelledby="edits-title">
        <div className="container-x">
          <Reveal>
            <p className="t-eyebrow eyebrow-rule mb-5 text-burgundy">The edits</p>
            <h2 id="edits-title" className="t-section mb-12 max-w-[16ch] text-wine md:mb-16">For the moments that matter</h2>
          </Reveal>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
            {edits.map((e, i) => (
              <Reveal key={e.title} delay={i * 110}>
                <Link href="/collections/sarees" className="group block">
                  <div className="zoom overflow-hidden">
                    <Media tone={e.tone} className="aspect-[4/3] w-full" />
                  </div>
                  <h3 className="t-title mt-5 text-wine">{e.title}</h3>
                  <p className="mt-2 text-[14px] text-ink/75">{e.line}</p>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Closing call to action */}
      <section className="on-dark relative flex min-h-[70svh] items-center overflow-hidden bg-burgundy text-center text-ivory" aria-labelledby="cta-title">
        <Media tone="burgundy" className="absolute inset-0 h-full w-full" />
        <div className="absolute inset-0 bg-wine/35" aria-hidden="true" />
        <div className="container-x relative z-10 py-24">
          <Reveal>
            <h2 id="cta-title" className="t-hero mx-auto mb-8 max-w-[14ch]">Rediscover yourself</h2>
            <p className="t-lead mx-auto mb-10 max-w-[32rem] text-ivory/90">Tell us what you are looking for and we will help you find it.</p>
            <Link href="/contact" className="btn btn-light">
              Contact us <Icon name="arrow-right" />
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
