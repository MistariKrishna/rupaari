import type { Metadata } from "next";
import Link from "next/link";
import { Icon } from "@/components/Icon";
import Media from "@/components/Media";
import PageHero from "@/components/PageHero";
import Reveal from "@/components/Reveal";
import { principles } from "@/lib/content";

export const metadata: Metadata = { title: "Our story", description: "The story behind RUPAARI." };

export default function AboutPage() {
  return (
    <>
      <PageHero eyebrow="Our story" title="A living heritage" intro="Heirloom spirit. Contemporary ease." />

      <section className="py-section">
        <div className="container-x grid items-center gap-12 md:grid-cols-2 md:gap-16">
          <Reveal variant="clip">
            <Media tone="taupe" className="aspect-[4/5] w-full" />
          </Reveal>
          <Reveal delay={150}>
            <p className="t-eyebrow eyebrow-rule mb-5 text-burgundy">Woven to endure</p>
            <p className="t-statement mb-8 text-wine">
              Let the silk lead. Luxury is conveyed through detail, never visual noise.
            </p>
            <p className="mb-6 max-w-[48ch] text-ink/85">
              RUPAARI is a warm, considered language for South Indian silk sarees: heritage in character, clarity in every interaction.
            </p>
            <p className="text-[14px] text-ink/60">Replace this copy with your approved brand story.</p>
          </Reveal>
        </div>
      </section>

      <section id="principles" className="on-dark scroll-mt-24 bg-wine py-section text-ivory">
        <div className="container-x">
          <Reveal>
            <p className="t-eyebrow eyebrow-rule mb-5">Principles</p>
            <h2 className="t-section mb-14 max-w-[14ch]">How we work</h2>
          </Reveal>
          <div className="grid gap-10 md:grid-cols-3">
            {principles.map((p, i) => (
              <Reveal key={p.n} delay={i * 120}>
                <div className="border-t border-gold pt-6">
                  <p className="mb-4 font-display text-[1.4rem] text-gold">{p.n}</p>
                  <h3 className="t-title mb-3">{p.title}</h3>
                  <p className="text-ivory/80">{p.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-section text-center">
        <Reveal className="container-x">
          <h2 className="t-section mx-auto mb-8 max-w-[16ch] text-wine">See the collection</h2>
          <Link href="/collections/sarees" className="btn">
            Explore sarees <Icon name="arrow-right" />
          </Link>
        </Reveal>
      </section>
    </>
  );
}
