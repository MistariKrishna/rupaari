// A template re-mounts on every navigation, so this gives each route a soft fade-in.
export default function Template({ children }: { children: React.ReactNode }) {
  return <div className="page-in">{children}</div>;
}
