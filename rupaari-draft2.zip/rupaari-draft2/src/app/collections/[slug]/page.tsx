import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Icon } from "@/components/Icon";
import Media from "@/components/Media";
import PageHero from "@/components/PageHero";
import Reveal from "@/components/Reveal";
import { collections, getCollection } from "@/lib/content";

type Params = Promise<{ slug: string }>;

export function generateStaticParams() {
  return collections.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const c = getCollection(slug);
  return c ? { title: c.title, description: c.blurb } : { title: "Not found" };
}

export default async function CollectionPage({ params }: { params: Params }) {
  const { slug } = await params;
  const collection = getCollection(slug);
  if (!collection) notFound();

  return (
    <>
      <PageHero eyebrow="Collection" title={collection.title} intro={collection.blurb} tone={collection.tone} />

      <section className="py-section">
        <div className="container-x">
          <div className="grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
            {collection.items.map((item, i) => (
              <Reveal key={item.name} delay={(i % 3) * 110}>
                <article className="group">
                  <div className="zoom overflow-hidden">
                    <Media tone={item.tone} className="aspect-[4/5] w-full" />
                  </div>
                  <h2 className="t-title mt-5 text-wine">{item.name}</h2>
                  <p className="mt-1 text-[14px] text-ink/70">{item.note}</p>
                </article>
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-16 flex flex-wrap items-center gap-6 border-t border-gold/50 pt-10">
            <p className="max-w-[40ch] text-ink/80">Photography, pricing and ordering will appear here once the catalogue is added.</p>
            <Link href="/contact" className="link-arrow text-burgundy">
              Ask about a piece <Icon name="arrow-right" />
            </Link>
          </Reveal>
        </div>
      </section>
    </>
  );
}
