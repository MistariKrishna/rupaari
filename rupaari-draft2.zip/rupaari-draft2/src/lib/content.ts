// SAMPLE content. Replace everything marked SAMPLE with verified facts before launch
// (design rule: never invent certification or scarcity).
export type Tone = "wine" | "burgundy" | "gold" | "taupe" | "ivory";

export interface CollectionInfo {
  slug: string;
  title: string;
  blurb: string;
  tone: Tone;
  items: { name: string; note: string; tone: Tone }[];
}

export const collections: CollectionInfo[] = [
  {
    slug: "sarees",
    title: "Sarees",
    blurb: "Silk sarees with woven borders, made to be worn and passed on.",
    tone: "wine",
    items: [
      { name: "Kanchipuram silk saree", note: "Silk", tone: "wine" },
      { name: "Koramangala pure silk", note: "Silk", tone: "burgundy" },
      { name: "Mysore silk saree", note: "Silk", tone: "gold" },
      { name: "Chettinad silk saree", note: "Silk", tone: "burgundy" },
      { name: "Pochampally ikat saree", note: "Ikat", tone: "taupe" },
      { name: "Gadwal silk saree", note: "Silk", tone: "wine" },
    ],
  },
  {
    slug: "kurtis",
    title: "Kurtis",
    blurb: "Handwoven silk kurtis with a clean, considered cut.",
    tone: "burgundy",
    items: [
      { name: "Handwoven silk kurti in ruby", note: "Silk", tone: "burgundy" },
      { name: "Handwoven silk kurti in cobalt", note: "Silk", tone: "wine" },
      { name: "Handwoven silk kurti in saffron", note: "Silk", tone: "gold" },
      { name: "Handwoven silk kurti in olive", note: "Silk", tone: "taupe" },
      { name: "Ikat kurti", note: "Ikat", tone: "burgundy" },
      { name: "Silk stole", note: "Silk", tone: "wine" },
    ],
  },
  {
    slug: "gift-craft",
    title: "Gift Craft",
    blurb: "Considered packaging and gifts to give a saree with care.",
    tone: "gold",
    items: [
      { name: "Saree gift box", note: "Gift packaging", tone: "gold" },
      { name: "Festive gift wrap", note: "Gift packaging", tone: "burgundy" },
    ],
  },
];

export function getCollection(slug: string): CollectionInfo | undefined {
  return collections.find((c) => c.slug === slug);
}

// SAMPLE figures: replace with real numbers, or remove the section.
export const stats: { value: number; suffix?: string; label: string }[] = [
  { value: 12, suffix: "+", label: "Weaving clusters" },
  { value: 250, suffix: "+", label: "Weaver families" },
  { value: 1500, suffix: "+", label: "Designs in the archive" },
  { value: 10000, suffix: "+", label: "Customers" },
  { value: 120, label: "New pieces each season" },
];

export const edits = [
  { title: "Bridal", line: "Heirloom silks for the day that matters.", tone: "wine" as Tone },
  { title: "Festive", line: "Colour and zari for gatherings and pooja.", tone: "burgundy" as Tone },
  { title: "Everyday", line: "Light handloom for ordinary, lovely days.", tone: "taupe" as Tone },
  { title: "Gifting", line: "A saree, given with care.", tone: "gold" as Tone },
];

export const principles = [
  { n: "01", title: "Space before ornament", text: "Keep surfaces warm, edges precise and gold rules fine." },
  { n: "02", title: "Silk before spectacle", text: "Accurate colour, natural skin and considered crops." },
  { n: "03", title: "Clarity before claims", text: "Use verified product details; never invent certification or scarcity." },
];

// SAMPLE process copy: describe your own process.
export const loomSteps = [
  { n: "01", title: "Yarn", text: "Silk and zari yarn are chosen for the piece." },
  { n: "02", title: "Colour", text: "Yarn is dyed to the shade the design calls for." },
  { n: "03", title: "Warp", text: "Threads are prepared and set on the loom." },
  { n: "04", title: "Weave", text: "The weaver builds the body, border and pallu by hand." },
  { n: "05", title: "Finish", text: "Each piece is checked, finished and packed with care." },
];
