// Site-wide settings. Fill in real details; empty values are hidden on the site.
export const site = {
  name: "RUPAARI",
  tagline: "Rediscover Yourself",
  contact: {
    address: "",
    phone: "",
    email: "",
  },
  shopHref: "/collections/sarees", // point to your online shop when it exists
  social: [
    { name: "Instagram", icon: "instagram", href: "" },
    { name: "Facebook", icon: "facebook", href: "" },
    { name: "Pinterest", icon: "pinterest", href: "" },
    { name: "LinkedIn", icon: "linkedin", href: "" },
  ] as const,
};

export const menu = [
  { label: "Home", href: "/" },
  {
    label: "Collections",
    href: "/collections/sarees",
    children: [
      { label: "Sarees", href: "/collections/sarees" },
      { label: "Kurtis", href: "/collections/kurtis" },
      { label: "Gift Craft", href: "/collections/gift-craft" },
    ],
  },
  {
    label: "About Us",
    href: "/about",
    children: [
      { label: "Our Story", href: "/about" },
      { label: "Principles", href: "/about#principles" },
    ],
  },
  { label: "The Loom", href: "/craft" },
  { label: "Sustainability", href: "/sustainability" },
  { label: "Contact", href: "/contact" },
];
